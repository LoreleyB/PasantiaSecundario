# Mcafee-Internship-projects

Go to read this doc --> Technical Schools
* FrontEnd
	**HTML + Angular
	
* BackEnd
	**JAVA
	**Python
