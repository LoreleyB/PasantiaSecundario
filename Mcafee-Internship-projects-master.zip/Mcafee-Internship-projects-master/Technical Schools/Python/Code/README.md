# ltc-sharding-dashboard
Dashboard to monitor the LTC 

### Create virtual env and install requirements

Cd ~/virtualenvs
virtualenv ltc-sharding-dashboard
source venv/bin/activate
pip install -r requirements.txt