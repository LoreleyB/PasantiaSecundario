﻿myApp = angular.module('myApp', ['ui.bootstrap', 'ngRoute']);


myApp.service('myService', function ($timeout) {
    this.Alert = function (dialogText, dialogTitle) {
        var alertModal = $('<div id="myModal" class="modal fade" tabindex="-1" role="dialog"> <div class="modal-dialog"> <div class="modal-content" style="width: 80%;"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal">×</button> <h3>' + (dialogTitle || 'Atención') + '</h3> </div> <div class="modal-body"><p>' + dialogText + '</p></div><div class="modal-footer"><button class="btn" data-dismiss="modal">Cerrar</button></div></div></div></div>');
        $timeout(function () { alertModal.modal(); });
    };

    this.Confirm = function (dialogText, okFunc, cancelFunc, dialogTitle, but1, but2) {
        var confirmModal = $('<div id="myModal" class="modal fade" tabindex="-1" role="dialog"> <div class="modal-dialog"> <div class="modal-content" style="width: 80%;"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal">×</button> <h3>' + dialogTitle + '</h3> </div> <div class="modal-body">' + dialogText + '</div><div class="modal-footer"><button ID="SiBtn" class="btn" data-dismiss="modal">' + (but1 == undefined ? 'Si' : but1) + '</button><button ID="NoBtn" class="btn" data-dismiss="modal">' + (but2 == undefined ? 'No' : but2) + '</button></div></div></div></div>');
        confirmModal.find('#SiBtn').click(function (event) {
            okFunc();
            confirmModal.modal('hide');
        });
        confirmModal.find('#NoBtn').click(function (event) {
            cancelFunc();
            confirmModal.modal('hide');
        });
        $timeout(function () { confirmModal.modal(); });
    };
    var contadorBloqueo = 0;
    var $dialog = $(
        '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
        '<div class="modal-dialog modal-m">' +
        '<div class="modal-content">' +
        '<div class="modal-header"><h3 style="margin:0;">Wait please...</h3></div>' +
        '<div class="modal-body">' +
        '<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar" style="width: 100%"></div></div>' +
        '</div></div></div></div>');
    this.BloquearPantalla = function () {
        contadorBloqueo++;
        if (contadorBloqueo == 1)
            $dialog.modal();
    };
    this.DesbloquearPantalla = function () {
        contadorBloqueo--;
        if (contadorBloqueo == 0)
            $timeout(function () { $dialog.modal('hide'); }, 100);
    };
})

myApp.factory('myHttpInterceptor', function ($q, myService) {
    var myHttpInterceptor = {
        request: function (config) {
            myService.BloquearPantalla();
            return config;
        },
        requestError: function (config) {
            return config;
        },
        response: function (response) {
            myService.DesbloquearPantalla();
            return response;
        },
        responseError: function (response) {
            myService.DesbloquearPantalla();
            if (response.status == 404 || response.status == 401) {
                myService.Alert("Denied access...");
            }
            else if (response.status == 400) {
                myService.Alert("Incorrect request...");
            }
            else if (response.data && response.data.ExceptionMessage) {

                myService.Alert(response.data.ExceptionMessage);
            }
            else {
                myService.Alert("Error in the application, retry again...");
            }
            return $q.reject(response);
        }
    }
    return myHttpInterceptor;
});

myApp.run(function ($rootScope, $http, $location, myService) {
    $rootScope.author = "Nano Reyes";
    $rootScope.selectEnvironmentVar = "INT";
});


myApp.config(function ($httpProvider, $routeProvider) {
	$httpProvider.interceptors.push('myHttpInterceptor');
    $httpProvider.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

    $routeProvider.
        when('/home',  
        {
            templateUrl: 'pages/home.html',
            controller: 'HomeCtrl'
        }).
        when('/groups',
        {
            templateUrl: 'pages/groups.html',
            controller: 'GroupsCtrl'
        })
        .when('/indexes',
        {
            templateUrl: 'pages/indexes.html',
            controller: 'IndexesCtrl'
        })
        .when('/nodes',
        {
            templateUrl: 'pages/nodes.html',
            controller: 'NodesCtrl'
        })
        .when('/cloudwatch',
        {
            templateUrl: 'pages/cloudwatch.html',
            controller: 'CloudWatchCtrl'
        })
        .otherwise(
        {
            redirectTo: '/home'
        });
});


myApp.controller('CloudWatchCtrl', function ($scope, $http, $rootScope) {

    $scope.Titulo = "Sharding Activity Catalog - CloudWatch";
    $scope.mariano = $rootScope.mariano;
    $scope.selectEnvironmentVar = $rootScope.selectEnvironmentVar;
    $scope.showAlarm = false;
    $scope.error = false;
    $scope.errorStatus = "";
    $scope.errorStatusText = "";
    $scope.metricAlarm = "";
    $scope.metricAlarmValues = "";
    $scope.showAlarmValues = false;
    $scope.metricAlarmValuesText = "";

    function cleanErrors() {
        $scope.error = false;
        $scope.errorStatus = "";
        $scope.errorStatusText = "";
        $scope.showAlarm = false;
        $scope.metricAlarmValues = "";
        $scope.showAlarmValues = false;
        $scope.metricAlarmValuesText = "";
	};

	$scope.parseDate = function (date) {
      return new Date(Date.parse(date));
    }

	$scope.checkCloudWatchStatus = function () {

        cleanErrors();

        $http.get("/api/cloudWatchStatus", {
            headers: {
                "env": $scope.selectEnvironmentVar
            }
            }).then(
            function (response) {
                 if(response != undefined){
                    $scope.showAlarm = true;
                    $scope.metricAlarm = response.data.MetricAlarms[0];
                    $scope.status = response.status + " " + response.statusText;
                 }

            }, function errorCallback(response){
                $scope.error = true;
                $scope.errorStatusText = response.statusText;
                $scope.errorStatus = response.status;
            });

    };

    $scope.checkCloudWatchValues = function () {

        cleanErrors();

        $http.get("/api/cloudWatchValues", {
            headers: {
                "env": $scope.selectEnvironmentVar
            }
            }).then(
            function (response) {
                 if(response != undefined){
                    $scope.metricAlarmValues = response.data.Datapoints;
                    $scope.metricAlarmValuesText =  response.data.Label;
                    $scope.showAlarmValues = true;
                 }

            }, function errorCallback(response){
                $scope.error = true;
                $scope.errorStatusText = response.statusText;
                $scope.errorStatus = response.status;
            });

    };
});

myApp.controller('NodesCtrl', function ($scope, $http, $rootScope) {

    $scope.Titulo = "Sharding Activity Catalog - Nodes";
    $scope.showIndexes = false;
    $scope.showNodes = false;
    $scope.es_indexes = [];
    $scope.es_nodes = [];
    $scope.es_nodes_final = [];
    $scope.mariano = $rootScope.mariano;
    $scope.selectEnvironmentVar = $rootScope.selectEnvironmentVar;
    $scope.error = false;
    $scope.errorStatus = "";
    $scope.errorStatusText = "";

	$scope.checkNodes = function () {

        $http.get("/api/checkNodes", {
            headers: {
                "env": $scope.selectEnvironmentVar
            }
            }).then(
            function (response) {
                if(response != undefined){
                    $scope.showNodes = true;
                    $scope.es_nodes = response.data;

                    $scope.es_nodes_final = [];

                    for (var i=0; i < $scope.es_nodes.length; i++) {
                        var myObj = {
                              heapPercent: $scope.es_nodes[i]["heap.percent"],
                              ramPercent: $scope.es_nodes[i]["ram.percent"],
                              ip: $scope.es_nodes[i]["ip"],
                              name: $scope.es_nodes[i]["name"],
                              master: $scope.es_nodes[i]["master"],
                              nodeRole: $scope.es_nodes[i]["node.role"]
                        };
                        $scope.es_nodes_final.push(myObj);
                    }
                }
            }, function errorCallback(response){
                $scope.error = true;
                $scope.errorStatusText = response.statusText;
                $scope.errorStatus = response.status;
            });

    };
});

myApp.controller('IndexesCtrl', function ($scope, $http, $rootScope) {
    $scope.Titulo = "Sharding Activity Catalog - Indexes";
    $scope.showIndexes = false;
    $scope.es_indexes = [];
    $scope.es_indexes_final = [];
    $scope.mariano = $rootScope.mariano;
    $scope.selectEnvironmentVar = $rootScope.selectEnvironmentVar;
    $scope.error = false;
    $scope.errorStatus = "";
    $scope.errorStatusText = "";
    $scope.indexName = "";
    $scope.showIndex = false;
    $scope.index_info = [];
    $scope.index_info_final = [];
    $scope.hits = [];

    function cleanErrors() {
        $scope.error = false;
        $scope.errorStatus = "";
        $scope.errorStatusText = "";
	};

	function cleanTables(){
	     $scope.showIndexes = false;
	     $scope.showIndex = false;
	};

	$scope.checkIndexes = function () {

        cleanErrors();
        cleanTables();

        $http.get("/api/checkIndexes", {
            headers: {
                "env": $scope.selectEnvironmentVar
            }
            }).then(
            function (response) {
                if(response != undefined){

                    $scope.showIndexes = true;
                    $scope.showIndexGroup = false;
                    $scope.es_indexes = response.data;
                    $scope.es_indexes_final = [];

                    for (var i=0; i < $scope.es_indexes.length; i++) {
                        var myObj = {
                              docsCount: $scope.es_indexes[i]["docs.count"],
                              index: $scope.es_indexes[i]["index"],
                              health: $scope.es_indexes[i]["health"],
                              status: $scope.es_indexes[i]["status"],
                              storeSize: $scope.es_indexes[i]["store.size"]
                        };
                        $scope.es_indexes_final.push(myObj);
                    }

                }
            }, function errorCallback(response){
                $scope.error = true;
                $scope.errorStatusText = response.statusText;
                $scope.errorStatus = response.status;
            });

    };

    $scope.checkIndexGroups = function () {

        cleanErrors();
        cleanTables();

        $http.get("/api/checkIndex", {
            headers: {
                "env": $scope.selectEnvironmentVar,
                "indexName": 'groups'
            }
        }).then(
        function (response) {
            if(response != undefined){

                //clean previous
                $scope.showIndexes = false;
                $scope.showIndex = false;
                $scope.index_info = [];
                $scope.hits = "";
                $scope.index_info_final = [];

                //new values
                $scope.showIndexGroup=true;
                $scope.index_info = response.data;
                $scope.hits = $scope.index_info.hits.hits[0]._source.groups;
                $scope.index_info_final = $scope.hits.length;

                for (var i=0; i < $scope.hits.length; i++) {
                    var myObj = {
                          name: $scope.hits[i]._source.name,
                          indexMonth: $scope.hits[i]._source.indexMonth,
                          indexYear: $scope.hits[i]._source.indexYear,
                          retentionGroup: $scope.hits[i]._source.retentionGroup,
                          channel: $scope.hits[i]._source.channel,
                          creationDate: $scope.hits[i]._source.creationDate,
                          periodBeginDate: $scope.hits[i]._source.periodBeginDate,
                          periodEndDate: $scope.hits[i]._source.periodEndDate
                    };
                    $scope.index_info_final.push(myObj);
                }

            }
        }, function errorCallback(response){
            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;
        });


    };

    $scope.checkIndexStats = function () {

        cleanErrors();
        cleanTables();

        $http.get("/api/checkIndex", {
            headers: {
                "env": $scope.selectEnvironmentVar,
                "indexName": 'indices_stats'
            }
        }).then(
        function (response) {
            if(response != undefined){

                $scope.showIndexes = false;
                $scope.showIndexGroup=false;
                $scope.showIndex = true;
                $scope.index_info = response.data;
                $scope.hits = $scope.index_info.hits.hits;
                $scope.index_info_final = [];

                for (var i=0; i < $scope.hits.length; i++) {
                    var myObj = {
                          name: $scope.hits[i]._source.name,
                          indexMonth: $scope.hits[i]._source.indexMonth,
                          indexYear: $scope.hits[i]._source.indexYear,
                          retentionGroup: $scope.hits[i]._source.retentionGroup,
                          channel: $scope.hits[i]._source.channel,
                          creationDate: $scope.hits[i]._source.creationDate,
                          periodBeginDate: $scope.hits[i]._source.periodBeginDate,
                          periodEndDate: $scope.hits[i]._source.periodEndDate
                    };
                    $scope.index_info_final.push(myObj);
                }

            }
        }, function errorCallback(response){
            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;
        });


    };
});



myApp.controller('HomeCtrl', function ($scope, $http, $rootScope) {

    $scope.Titulo = "Sharding Activity Catalog - Home";
    $scope.build = "0.0.0";
    $scope.currentSetting = "NoN";
    $scope.healthy = false;
    $scope.status = "RED";
    $scope.components = [];
    $scope.CheckStatus;
    $scope.valueRange = 0;
    $scope.selectEnvironmentVar = "INT";
    $scope.error = false;
    $scope.errorStatus = "";
    $scope.errorStatusText = "";
    $scope.token = "";
    $scope.isToken = false;
    $scope.mariano = $rootScope.mariano;
    $scope.selectEnvironmentVar = $rootScope.selectEnvironmentVar;

	$scope.selectEnvironment = function () {
	    cleanValues();
        cleanErrors ();

	    if ($scope.valueRange == "0" ){
            $rootScope.selectEnvironmentVar = "INT";
            $scope.selectEnvironmentVar = "INT";
        }

        if ($scope.valueRange == "1" ){
            $rootScope.selectEnvironmentVar = "DEV";
            $scope.selectEnvironmentVar = "DEV";
        }

        if ($scope.valueRange == "2" ){
            $rootScope.selectEnvironmentVar = "DEMO";
            $scope.selectEnvironmentVar = "DEMO";
        }

        if ($scope.valueRange == "3" ){
            $rootScope.selectEnvironmentVar = "PRE";
            $scope.selectEnvironmentVar = "PRE";
        }

        if ($scope.valueRange == "4" ){
            $rootScope.selectEnvironmentVar = "PROD";
            $scope.selectEnvironmentVar = "PROD";
        }
	};

	function cleanValues() {
        $scope.token = "";
        $scope.isToken = false;
        $scope.components = [];
	};

	function cleanErrors() {
        $scope.error = false;
        $scope.errorStatus = "";
        $scope.errorStatusText = "";
	};


	$scope.GetToken = function (){
	    cleanErrors();
	    if ($scope.selectEnvironmentVar != 'PROD'){
	        $http.get("/api/getToken", {
                headers: {
                    "env": $scope.selectEnvironmentVar
                }
            }).then(function (response) {
                if(response.data != undefined){
                    $scope.error = false;
                    $scope.token = response.data.AuthorizationToken;
                    $scope.isToken = true;
                }
            }, function errorCallback(response){
                $scope.error = true;
                $scope.errorStatusText = response.statusText;
                $scope.errorStatus = response.status;
            });
	    }else{
	        $scope.error = true;
	        $scope.errorStatusText = "The request was valid, but the server is refusing action. The user might not have the necessary permissions for a resource, or may need an account of some sort.";
            $scope.errorStatus = "403";
	    }

	};

	$scope.CheckStatus = function () {
	    cleanErrors();

        $http.get("/api/checkHealth", {
        headers: {
            "tok": $scope.token,
            "env": $scope.selectEnvironmentVar
            }
        }).then(function (response) {
            if(response.data != undefined){
                $scope.error = false;
                var respJson = response.data;
                $scope.build = respJson.data.build;
                $scope.currentSetting = respJson.data.currentSetting;
                $scope.healthy = respJson.data.healthy;
                $scope.version = respJson.data.version;
                $scope.components = respJson.data.items;
                $scope.status = "GREEN";
            }
        }, function errorCallback(response){

            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;

        });
    };
});


myApp.controller('GroupsCtrl', function ($scope, myService, $http, $rootScope) {

	$scope.Titulo = "Sharding Activity Catalog -  Groups";
	$scope.groups_im = [];
	$scope.groups_es = [];
	$scope.error = false;
    $scope.errorStatus = "";
    $scope.errorStatusText = "";
	$scope.mariano = $rootScope.mariano;
    $scope.selectEnvironmentVar = $rootScope.selectEnvironmentVar;
    $scope.tenants_total = 0;
    $scope.tenants_max_etcd = 0;
    $scope.nodes_total = 0;

	$scope.clean = function () {
	     $scope.Tenants_im = [];
	     $scope.Nodes_im = [];
	     $scope.Tenants_es = [];
	     $scope.Nodes_es = [];
	     $scope.groups_im = [];
	     $scope.groups_es = [];
	     $scope.tenants_total = 0;
	     $scope.nodes_total = 0;
	     $scope.tenants_max_etcd = 0;
	};

	$scope.getTenantsMaxETCD = function () {

        $http.get("/api/getTenantsMaxETCD", {
            headers: {
                "env": $scope.selectEnvironmentVar
            }
        }).then(
        function (response) {
            if(response != undefined){
                $scope.tenants_max_etcd = response.data.allowed;
            }
        }, function errorCallback(response){
            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;
        });


    };


	$scope.FindIM = function () {
        $scope.tenants_total = 0;
        $scope.nodes_total = 0;
		$http.get("/api/groupsIM", {
        headers: {
            "env": $scope.selectEnvironmentVar
            }
        }).then(function (response) {
            if(response.data != undefined){
                $scope.groups_im = response.data;
                for (var i=0; i < $scope.groups_im.groups.length; i++) {
                    $scope.tenants_total = $scope.tenants_total + $scope.groups_im.groups[i].tenants.length;
                    $scope.nodes_total = $scope.nodes_total + $scope.groups_im.groups[i].nodes.length;
                }

                $scope.groups_es = [];
                $scope.getTenantsMaxETCD();
            }

        }, function errorCallback(response){
            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;

        });

	};


	$scope.FindES = function () {
        $scope.tenants_total = 0;
        $scope.nodes_total = 0;
	    $http.get("/api/groupsES", {
        headers: {
            "env": $scope.selectEnvironmentVar
            }
        }).then(function (response) {
            if(response.data != undefined){
                var group = response.data;
                $scope.groups_es = group.hits.hits[0]._source;
                for (var i=0; i < $scope.groups_es.groups.length; i++) {
                    $scope.tenants_total = $scope.tenants_total + $scope.groups_es.groups[i].tenants.length;
                    $scope.nodes_total = $scope.nodes_total + $scope.groups_es.groups[i].nodes.length;
                }

                $scope.groups_im = [];
                $scope.getTenantsMaxETCD();
            }
        }, function errorCallback(response){

            $scope.error = true;
            $scope.errorStatusText = response.statusText;
            $scope.errorStatus = response.status;

        });

	};

  }
);

