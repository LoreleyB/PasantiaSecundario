from datetime import datetime
from functools import wraps, update_wrapper
import json

import requests
from amazon import Amazon
from flask import Flask, request, send_from_directory, make_response, jsonify


def nocache(view):
    @wraps(view)
    def no_cache(*args, **kwargs):
        response = make_response(view(*args, **kwargs))
        response.headers['Last-Modified'] = datetime.now()
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '-1'
        return response

    return update_wrapper(no_cache, view)


env = "int"

MILK_DUDS = 'onboarding'

# set the project root directory as the static folder, you can set others.
app = Flask(__name__, static_url_path='/static/')


@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('static/js', path)


@app.route('/img/<path:path>')
def send_images(path):
    return send_from_directory('static/img', path)


@app.route('/css/<path:path>')
def send_styles(path):
    return send_from_directory('static/css', path)


@app.route('/fonts/<path:path>')
def send_fonts(path):
    return send_from_directory('static/fonts', path)


@app.route('/pages/<path:path>')
def send_pages(path):
    return send_from_directory('static/pages', path)


@app.route('/')
@nocache
def root():
    return app.send_static_file('index.html')


@app.route('/api/getTenantsMaxETCD', methods=['GET'])
def get_tenants_max_etcd_value():
    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/im:80/index-mgr/api/v1/groups/tenants"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/cloudWatchValues', methods=['GET'])
def get_cloud_watch_alarm_values():

    env = request.headers.get("env")

    if env == "INT":
        aws_secret_key = "SGdMOjW37GjRNZbw/9aFVV7Am5JYVacvEMi1zK0G"
        aws_access_key = "AKIAINBFEDWDA47SX5IA"
        namespace = 'intderweze'
    elif env == "DEMO":
        aws_secret_key = "QUwFakLczPLVW4gK2aegxSYdL9UnP2Up1Qp6n1sY"
        aws_access_key = "AKIAJSSWLKLO46ECKDPQ"
        namespace = 'prederweze'
    elif env == "PRE":
        aws_secret_key = "QUwFakLczPLVW4gK2aegxSYdL9UnP2Up1Qp6n1sY"
        aws_access_key = "AKIAJSSWLKLO46ECKDPQ"
        namespace = 'demo1derweze'
    elif env == "PROD":
        aws_secret_key = "UVFRpl7CF3GdL6CrUMgzXc6cw2Iw5ghy+YgG3ySO"
        aws_access_key = "AKIAIPPRF7LNPV3DZ2UQ"
        namespace = 'invpderweze'
    else:
        return "BAD REQUEST - invalid parameter", 400

    try:
        amazon_client = Amazon(
            aws_access_key,
            aws_secret_key,
            "us-west-2"
        )

        results = amazon_client.describe_alarm_for_metric(namespace)

        return jsonify(results), 200

    except:
        return 'Error UPS', 500


@app.route('/api/cloudWatchStatus', methods=['GET'])
def get_cloud_watch_alarm_status():

    env = request.headers.get("env")

    if env == "INT":
        aws_secret_key = "SGdMOjW37GjRNZbw/9aFVV7Am5JYVacvEMi1zK0G"
        aws_access_key = "AKIAINBFEDWDA47SX5IA"
        alarm = "int-tenant-group-capacity"
    elif env == "DEMO":
        aws_secret_key = "QUwFakLczPLVW4gK2aegxSYdL9UnP2Up1Qp6n1sY"
        aws_access_key = "AKIAJSSWLKLO46ECKDPQ"
        alarm = "tenant-group-capacity"
    elif env == "PRE":
        aws_secret_key = "QUwFakLczPLVW4gK2aegxSYdL9UnP2Up1Qp6n1sY"
        aws_access_key = "AKIAJSSWLKLO46ECKDPQ"
        alarm = "pre-tenant-group-capacity"
    elif env == "PROD":
        aws_secret_key = "UVFRpl7CF3GdL6CrUMgzXc6cw2Iw5ghy+YgG3ySO"
        aws_access_key = "AKIAIPPRF7LNPV3DZ2UQ"
        alarm = "tenant-group-capacity"
    else:
        return "BAD REQUEST - invalid parameter", 400

    try:
        amazon_client = Amazon(
            aws_access_key,
            aws_secret_key,
            "us-west-2"
        )

        results = amazon_client.get_alarm(alarm)

        return jsonify(results), 200

    except:

        return 'Error UPS', 500


@app.route('/api/groupsIM', methods=['GET'])
def get_groups_im():

    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/im:80/index-mgr/api/v1/groups"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service,headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/groupsES', methods=['GET'])
def get_groups_es():

    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/ltc:9200/groups/_search?size=1000"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/getToken', methods=['GET'])
def get_token_ltc():
    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "DEV":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "api-"
        param_env2 = "-cop.soc.mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "api-"
        param_env2 = "-cop.soc.mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://" + param_env1 + param_env + param_env2 + "/identity/v1/login"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False, auth=(MILK_DUDS, MILK_DUDS))

    return r.content, r.status_code


@app.route('/api/checkHealth', methods=['GET'])
def check_health_ltc():

    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "DEV":
        param_env = "derweze046"
        param_env1 = "derweze"
        param_env2 = ".dev-tmp.com"
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/ltc:80/api/v1/ltc/health"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/checkIndexes', methods=['GET'])
def check_indexes():
    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/ltc:9200/_cat/indices?h=index,docs.count,store.size,status,health&s=index:asc&size=1000&format=json"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/checkIndex', methods=['GET'])
def check_index():
    param_env = request.headers.get("env")
    index_name = request.headers.get("indexName")

    if not index_name:
        return "BAD REQUEST - invalid parameter", 400

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/ltc:9200/" + index_name + "/_search?size=10000"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


@app.route('/api/checkNodes', methods=['GET'])
def check_nodes():
    param_env = request.headers.get("env")

    if not param_env:
        param_env = env
    elif param_env == "INT":
        param_env = "int"
        param_env1 = "int"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "DEMO":
        param_env = "demo1"
        param_env1 = "demo1"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PRE":
        param_env = "pre"
        param_env1 = "pre"
        param_env2 = ".cop-mcafee.com"
    elif param_env == "PROD":
        param_env = "invp"
        param_env1 = "investigator"
        param_env2 = ".ccs-mcafee.com"
    else:
        return "BAD REQUEST - invalid parameter", 400

    url_service = "https://bastion." + param_env + "." + param_env1 + param_env2 + "/api/v1/proxy/namespaces/" + param_env + "derweze/services/ltc:9200/_cat/nodes?v&s=name:asc&format=json&pretty=true"

    headers = {
        "Content-Type": "application/json"
    }

    r = requests.get(url_service, headers=headers, verify=False)

    return r.content, r.status_code


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=9090, processes=5, debug=True)
